package com.APITeste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class APITesteApplication {

    public static void main(String[] args) {
        SpringApplication.run(APITesteApplication.class, args);
    }
}
