INSERT INTO USUARIO(
NOME,
EMAIL,
DATA_NASCIMENTO,
ENDERECO,
HABILIDADES)
VALUES(
'Harry Potter',
'edwiges@gmail.com',
'1980-07-31',
'The cupboard under the stairs, 4, Privet Drive',
'{"Accio", "Expecto Patronum", "Expelliarmus"}');