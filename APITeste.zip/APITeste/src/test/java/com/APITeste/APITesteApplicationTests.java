package com.APITeste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class APITesteApplicationTests {

	@Test
	void contextLoads() {
	}
}
